// ─────────────────────────────────────────────────────────────────────────
// General / World Cuisine Nutrition Database
//
// Same shape and purpose as indian-food-db.js — a curated, per-100g
// nutrition table for common homemade/restaurant dish components,
// as-cooked/as-served (with typical oil/butter/sauce), so figures line
// up with visual gram estimates from a plate photo.
//
// This exists because Open Food Facts is overwhelmingly *packaged*
// branded products and has poor coverage of generic prepared dishes —
// that gap isn't unique to Indian food, it's true for Italian, Mexican,
// Chinese, American, Mediterranean, and breakfast staples too. Before
// this file, anything outside the Indian DB fell straight through to
// raw per-ingredient VLM guessing (Tier 3), which is the least accurate
// path. This file gives those cuisines the same Tier-1 grounding.
//
// Checked in analyse.js AFTER the Indian DB (which stays more specific
// for South Asian dishes) and BEFORE Open Food Facts search.
// ─────────────────────────────────────────────────────────────────────────

// Each entry: kcal, carbs, protein, fat, fiber, sugars, satFat — all per 100g.
const WORLD_FOOD_DB = [
  // ---- Italian ----
  { keys: ["spaghetti bolognese", "pasta bolognese", "bolognese"], kcal: 155, carbs: 16, protein: 8, fat: 6.5, fiber: 1.5, sugars: 3, satFat: 2.5 },
  { keys: ["carbonara", "pasta carbonara"], kcal: 200, carbs: 18, protein: 8, fat: 11, fiber: 1, sugars: 1, satFat: 5 },
  { keys: ["lasagna", "lasagne"], kcal: 165, carbs: 14, protein: 9, fat: 8.5, fiber: 1.5, sugars: 3, satFat: 4 },
  { keys: ["plain pasta", "pasta with tomato sauce", "pasta pomodoro", "spaghetti"], kcal: 145, carbs: 25, protein: 5, fat: 3, fiber: 2, sugars: 3, satFat: 0.6 },
  { keys: ["pizza margherita", "cheese pizza", "pizza"], kcal: 265, carbs: 33, protein: 11, fat: 10, fiber: 2, sugars: 3.5, satFat: 4.5 },
  { keys: ["risotto"], kcal: 175, carbs: 25, protein: 4, fat: 6, fiber: 1, sugars: 1, satFat: 3 },
  { keys: ["garlic bread"], kcal: 350, carbs: 45, protein: 8, fat: 15, fiber: 2, sugars: 2, satFat: 6 },

  // ---- Mexican ----
  { keys: ["chicken taco", "beef taco", "taco"], kcal: 210, carbs: 18, protein: 12, fat: 10, fiber: 2.5, sugars: 1.5, satFat: 3.5 },
  { keys: ["burrito"], kcal: 210, carbs: 26, protein: 9, fat: 8, fiber: 3.5, sugars: 1.5, satFat: 3 },
  { keys: ["quesadilla"], kcal: 280, carbs: 22, protein: 12, fat: 16, fiber: 1.5, sugars: 1.5, satFat: 7 },
  { keys: ["enchilada"], kcal: 190, carbs: 17, protein: 9, fat: 10, fiber: 2.5, sugars: 2, satFat: 4 },
  { keys: ["guacamole"], kcal: 155, carbs: 8.5, protein: 2, fat: 14, fiber: 6.5, sugars: 0.7, satFat: 2 },
  { keys: ["mexican rice", "rice and beans"], kcal: 150, carbs: 26, protein: 4.5, fat: 3.5, fiber: 3, sugars: 1, satFat: 0.6 },
  { keys: ["nachos"], kcal: 320, carbs: 30, protein: 8, fat: 19, fiber: 2.5, sugars: 2, satFat: 7 },

  // ---- East / Southeast Asian ----
  { keys: ["fried rice"], kcal: 185, carbs: 25, protein: 5, fat: 6.5, fiber: 1, sugars: 1.5, satFat: 1.2 },
  { keys: ["chow mein", "lo mein", "noodles"], kcal: 175, carbs: 24, protein: 6, fat: 6, fiber: 1.5, sugars: 2, satFat: 1 },
  { keys: ["general tso", "sweet and sour chicken", "orange chicken"], kcal: 230, carbs: 22, protein: 13, fat: 10, fiber: 0.5, sugars: 12, satFat: 2 },
  { keys: ["kung pao chicken", "stir fry chicken", "chicken stir fry", "stir fry"], kcal: 170, carbs: 9, protein: 15, fat: 8.5, fiber: 1.5, sugars: 4, satFat: 1.5 },
  { keys: ["dumpling", "gyoza", "momo"], kcal: 210, carbs: 24, protein: 8, fat: 9, fiber: 1.2, sugars: 1, satFat: 2 },
  { keys: ["spring roll", "egg roll"], kcal: 230, carbs: 26, protein: 5, fat: 12, fiber: 1.5, sugars: 1.5, satFat: 2 },
  { keys: ["ramen"], kcal: 130, carbs: 18, protein: 6, fat: 4, fiber: 1, sugars: 1, satFat: 1.5 },
  { keys: ["pad thai"], kcal: 180, carbs: 22, protein: 8, fat: 6.5, fiber: 1.5, sugars: 6, satFat: 1.5 },
  { keys: ["green curry", "red curry", "thai curry"], kcal: 145, carbs: 6, protein: 8, fat: 10, fiber: 1.5, sugars: 3, satFat: 6.5 },
  { keys: ["sushi roll", "california roll", "sushi"], kcal: 145, carbs: 28, protein: 5, fat: 1.5, fiber: 1, sugars: 4, satFat: 0.3 },
  { keys: ["teriyaki chicken", "teriyaki"], kcal: 185, carbs: 12, protein: 18, fat: 6.5, fiber: 0.2, sugars: 9, satFat: 1.5 },

  // ---- Middle Eastern / Mediterranean ----
  { keys: ["hummus"], kcal: 165, carbs: 14, protein: 8, fat: 9.5, fiber: 6, sugars: 0.3, satFat: 1.3 },
  { keys: ["falafel"], kcal: 335, carbs: 32, protein: 13, fat: 18, fiber: 5, sugars: 1.5, satFat: 2.3 },
  { keys: ["shawarma"], kcal: 210, carbs: 12, protein: 17, fat: 10.5, fiber: 1.5, sugars: 1.5, satFat: 3 },
  { keys: ["gyro"], kcal: 220, carbs: 14, protein: 16, fat: 11, fiber: 1, sugars: 2, satFat: 4 },
  { keys: ["kebab", "kabab", "seekh kebab", "shish kebab"], kcal: 210, carbs: 4, protein: 20, fat: 13, fiber: 0.5, sugars: 1, satFat: 4.5 },
  { keys: ["tabbouleh"], kcal: 90, carbs: 12, protein: 2.5, fat: 4, fiber: 3, sugars: 1.5, satFat: 0.5 },
  { keys: ["greek salad"], kcal: 105, carbs: 5, protein: 3, fat: 8.5, fiber: 2, sugars: 3, satFat: 3 },
  { keys: ["tzatziki"], kcal: 75, carbs: 3.5, protein: 3.5, fat: 5.5, fiber: 0.3, sugars: 3, satFat: 3 },
  { keys: ["pita bread", "pita"], kcal: 275, carbs: 55, protein: 9, fat: 1.5, fiber: 2.5, sugars: 2, satFat: 0.3 },

  // ---- American / general home-style ----
  { keys: ["cheeseburger", "burger", "hamburger"], kcal: 260, carbs: 20, protein: 14, fat: 14, fiber: 1.5, sugars: 4, satFat: 6 },
  { keys: ["fried chicken"], kcal: 260, carbs: 10, protein: 20, fat: 16, fiber: 0.5, sugars: 0.5, satFat: 4 },
  { keys: ["grilled chicken breast", "chicken breast", "grilled chicken"], kcal: 165, carbs: 0, protein: 31, fat: 3.6, fiber: 0, sugars: 0, satFat: 1 },
  { keys: ["mac and cheese", "macaroni cheese"], kcal: 195, carbs: 20, protein: 8, fat: 9.5, fiber: 1, sugars: 3, satFat: 5 },
  { keys: ["mashed potato", "mashed potatoes"], kcal: 105, carbs: 16, protein: 2, fat: 4, fiber: 1.5, sugars: 1.5, satFat: 2.5 },
  { keys: ["roast chicken"], kcal: 190, carbs: 0, protein: 27, fat: 9, fiber: 0, sugars: 0, satFat: 2.5 },
  { keys: ["meatloaf"], kcal: 200, carbs: 6, protein: 15, fat: 13, fiber: 0.5, sugars: 2, satFat: 5 },
  { keys: ["caesar salad"], kcal: 160, carbs: 6, protein: 6, fat: 13, fiber: 1.5, sugars: 1.5, satFat: 2.5 },
  { keys: ["garden salad", "side salad", "green salad"], kcal: 45, carbs: 5, protein: 1.5, fat: 2.5, fiber: 2, sugars: 2.5, satFat: 0.3 },
  { keys: ["steak", "grilled steak", "beef steak"], kcal: 250, carbs: 0, protein: 26, fat: 16, fiber: 0, sugars: 0, satFat: 6.5 },
  { keys: ["grilled salmon", "salmon"], kcal: 205, carbs: 0, protein: 22, fat: 13, fiber: 0, sugars: 0, satFat: 2.5 },
  { keys: ["french fries", "fries", "chips"], kcal: 315, carbs: 41, protein: 3.5, fat: 15, fiber: 3.5, sugars: 0.3, satFat: 2.5 },
  { keys: ["roasted vegetables", "grilled vegetables"], kcal: 90, carbs: 11, protein: 2, fat: 4.5, fiber: 3, sugars: 4, satFat: 0.6 },
  { keys: ["sandwich"], kcal: 250, carbs: 28, protein: 11, fat: 10, fiber: 2.5, sugars: 3, satFat: 2.5 },
  { keys: ["grilled cheese sandwich", "grilled cheese"], kcal: 310, carbs: 28, protein: 11, fat: 18, fiber: 1.5, sugars: 3, satFat: 9 },

  // ---- Breakfast staples ----
  { keys: ["scrambled eggs", "scrambled egg"], kcal: 155, carbs: 1.5, protein: 11, fat: 11.5, fiber: 0, sugars: 1, satFat: 3.5 },
  { keys: ["omelette", "omelet"], kcal: 165, carbs: 1.5, protein: 11, fat: 12.5, fiber: 0, sugars: 1, satFat: 4 },
  { keys: ["boiled egg", "hard boiled egg", "fried egg"], kcal: 155, carbs: 1, protein: 13, fat: 11, fiber: 0, sugars: 1, satFat: 3.3 },
  { keys: ["oatmeal", "porridge"], kcal: 70, carbs: 12, protein: 2.5, fat: 1.5, fiber: 1.7, sugars: 0.5, satFat: 0.3 },
  { keys: ["pancake", "pancakes"], kcal: 230, carbs: 30, protein: 6, fat: 9, fiber: 1, sugars: 8, satFat: 2 },
  { keys: ["waffle", "waffles"], kcal: 290, carbs: 34, protein: 7, fat: 13, fiber: 1.5, sugars: 8, satFat: 2.5 },
  { keys: ["bacon"], kcal: 480, carbs: 1.5, protein: 30, fat: 39, fiber: 0, sugars: 0, satFat: 13 },
  { keys: ["buttered toast", "toast with butter"], kcal: 310, carbs: 40, protein: 7, fat: 13, fiber: 2.5, sugars: 3, satFat: 6 },
  { keys: ["plain toast", "bread slice", "toast"], kcal: 265, carbs: 49, protein: 9, fat: 3.5, fiber: 2.7, sugars: 4, satFat: 0.7 },
  { keys: ["avocado toast"], kcal: 220, carbs: 22, protein: 6, fat: 12.5, fiber: 4.5, sugars: 1.5, satFat: 2 },
  { keys: ["yogurt with granola", "granola"], kcal: 200, carbs: 26, protein: 6, fat: 8, fiber: 3, sugars: 10, satFat: 1.5 },

  // ---- French ----
  { keys: ["coq au vin"], kcal: 175, carbs: 4, protein: 16, fat: 10, fiber: 0.8, sugars: 2, satFat: 3 },
  { keys: ["beef bourguignon", "boeuf bourguignon"], kcal: 190, carbs: 5, protein: 17, fat: 11, fiber: 1, sugars: 2, satFat: 4.2 },
  { keys: ["ratatouille"], kcal: 65, carbs: 8, protein: 1.8, fat: 3.5, fiber: 2.5, sugars: 5, satFat: 0.5 },
  { keys: ["quiche lorraine", "quiche"], kcal: 280, carbs: 15, protein: 9, fat: 21, fiber: 0.8, sugars: 2, satFat: 10 },
  { keys: ["french onion soup", "onion soup"], kcal: 85, carbs: 8, protein: 4, fat: 4, fiber: 1, sugars: 4, satFat: 2.2 },
  { keys: ["croque monsieur"], kcal: 320, carbs: 22, protein: 16, fat: 19, fiber: 1, sugars: 2.5, satFat: 10 },
  { keys: ["crepe", "crêpe"], kcal: 220, carbs: 27, protein: 6, fat: 9, fiber: 0.8, sugars: 5, satFat: 3.5 },
  { keys: ["croissant"], kcal: 410, carbs: 45, protein: 8, fat: 21, fiber: 2, sugars: 8, satFat: 12 },
  { keys: ["baguette", "french bread"], kcal: 270, carbs: 55, protein: 9, fat: 1.5, fiber: 2.5, sugars: 3, satFat: 0.3 },

  // ---- Korean ----
  { keys: ["bibimbap"], kcal: 150, carbs: 20, protein: 6, fat: 5, fiber: 2, sugars: 3, satFat: 1.2 },
  { keys: ["bulgogi"], kcal: 195, carbs: 8, protein: 18, fat: 10, fiber: 0.5, sugars: 6, satFat: 3.5 },
  { keys: ["korean fried chicken"], kcal: 290, carbs: 18, protein: 18, fat: 17, fiber: 0.3, sugars: 8, satFat: 3.5 },
  { keys: ["kimchi jjigae", "kimchi stew"], kcal: 75, carbs: 6, protein: 6, fat: 3, fiber: 2, sugars: 2, satFat: 1 },
  { keys: ["kimchi"], kcal: 25, carbs: 4, protein: 1.6, fat: 0.4, fiber: 2, sugars: 2, satFat: 0.1 },
  { keys: ["japchae"], kcal: 155, carbs: 25, protein: 3, fat: 5, fiber: 1, sugars: 4, satFat: 0.7 },
  { keys: ["tteokbokki"], kcal: 200, carbs: 40, protein: 4, fat: 3, fiber: 1.2, sugars: 8, satFat: 0.4 },

  // ---- Vietnamese ----
  { keys: ["pho", "beef pho", "chicken pho"], kcal: 90, carbs: 12, protein: 7, fat: 2, fiber: 0.5, sugars: 1, satFat: 0.7 },
  { keys: ["banh mi"], kcal: 240, carbs: 30, protein: 10, fat: 9, fiber: 1.5, sugars: 3, satFat: 2 },
  { keys: ["vietnamese spring roll", "goi cuon", "summer roll"], kcal: 105, carbs: 15, protein: 6, fat: 2, fiber: 1.2, sugars: 2, satFat: 0.3 },
  { keys: ["bun cha"], kcal: 155, carbs: 14, protein: 11, fat: 6.5, fiber: 1, sugars: 4, satFat: 2 },

  // ---- Caribbean ----
  { keys: ["jerk chicken"], kcal: 195, carbs: 3, protein: 22, fat: 10, fiber: 0.5, sugars: 2, satFat: 2.8 },
  { keys: ["rice and peas"], kcal: 165, carbs: 28, protein: 4, fat: 4.5, fiber: 3, sugars: 1, satFat: 2.5 },
  { keys: ["curry goat"], kcal: 210, carbs: 4, protein: 20, fat: 13, fiber: 0.8, sugars: 1.5, satFat: 4.5 },
  { keys: ["oxtail stew"], kcal: 230, carbs: 5, protein: 18, fat: 16, fiber: 0.8, sugars: 2, satFat: 6.5 },
  { keys: ["plantain", "fried plantain"], kcal: 165, carbs: 32, protein: 1, fat: 4.5, fiber: 2, sugars: 15, satFat: 0.8 },

  // ---- South American ----
  { keys: ["feijoada"], kcal: 160, carbs: 12, protein: 12, fat: 7.5, fiber: 5, sugars: 1.5, satFat: 2.8 },
  { keys: ["empanada"], kcal: 260, carbs: 26, protein: 8, fat: 13, fiber: 1.5, sugars: 1.5, satFat: 4.5 },
  { keys: ["ceviche"], kcal: 95, carbs: 6, protein: 15, fat: 1.5, fiber: 0.5, sugars: 2, satFat: 0.3 },
  { keys: ["arepa"], kcal: 210, carbs: 40, protein: 4.5, fat: 3.5, fiber: 3, sugars: 0.5, satFat: 0.5 },
  { keys: ["churrasco", "grilled beef skewer"], kcal: 245, carbs: 0, protein: 25, fat: 16, fiber: 0, sugars: 0, satFat: 6.5 },
  { keys: ["pastel de choclo"], kcal: 175, carbs: 20, protein: 8, fat: 7, fiber: 2, sugars: 5, satFat: 2.5 },

  // ---- German / Central European ----
  { keys: ["schnitzel", "wiener schnitzel"], kcal: 270, carbs: 15, protein: 20, fat: 15, fiber: 0.8, sugars: 1, satFat: 3.5 },
  { keys: ["bratwurst", "sausage"], kcal: 300, carbs: 2, protein: 13, fat: 27, fiber: 0, sugars: 0.5, satFat: 9.5 },
  { keys: ["sauerkraut"], kcal: 20, carbs: 4, protein: 1, fat: 0.1, fiber: 3, sugars: 2, satFat: 0 },
  { keys: ["pretzel", "soft pretzel"], kcal: 340, carbs: 68, protein: 9, fat: 3, fiber: 2.5, sugars: 3, satFat: 0.7 },
  { keys: ["goulash"], kcal: 145, carbs: 8, protein: 12, fat: 7, fiber: 1.5, sugars: 3, satFat: 2.5 },
  { keys: ["perogies", "pierogi"], kcal: 220, carbs: 30, protein: 6, fat: 8, fiber: 1.5, sugars: 1, satFat: 3 },

  // ---- African ----
  { keys: ["jollof rice"], kcal: 175, carbs: 28, protein: 4, fat: 5.5, fiber: 1.5, sugars: 3, satFat: 1 },
  { keys: ["injera"], kcal: 165, carbs: 34, protein: 6, fat: 0.8, fiber: 3, sugars: 0.5, satFat: 0.1 },
  { keys: ["doro wat", "ethiopian chicken stew"], kcal: 165, carbs: 6, protein: 15, fat: 9, fiber: 1.5, sugars: 2, satFat: 2.5 },
  { keys: ["tagine", "chicken tagine", "lamb tagine"], kcal: 175, carbs: 8, protein: 15, fat: 9, fiber: 2, sugars: 4, satFat: 2.2 },
  { keys: ["couscous"], kcal: 115, carbs: 23, protein: 3.8, fat: 0.2, fiber: 1.4, sugars: 0.2, satFat: 0 },
  { keys: ["suya", "grilled spiced meat skewer"], kcal: 250, carbs: 3, protein: 24, fat: 16, fiber: 1, sugars: 1, satFat: 5.5 },
  { keys: ["egusi soup"], kcal: 145, carbs: 6, protein: 8, fat: 10, fiber: 2.5, sugars: 1.5, satFat: 2.8 },

  // ---- Additional Mediterranean / Middle Eastern ----
  { keys: ["moussaka"], kcal: 175, carbs: 8, protein: 9, fat: 12, fiber: 1.8, sugars: 3, satFat: 5 },
  { keys: ["spanakopita"], kcal: 235, carbs: 18, protein: 7, fat: 15, fiber: 2, sugars: 1.5, satFat: 6 },
  { keys: ["paella"], kcal: 170, carbs: 22, protein: 9, fat: 5, fiber: 1, sugars: 1.5, satFat: 1 },
  { keys: ["shakshuka"], kcal: 110, carbs: 7, protein: 7, fat: 6.5, fiber: 2, sugars: 4, satFat: 1.8 },
  { keys: ["baba ganoush"], kcal: 105, carbs: 7, protein: 2.5, fat: 8, fiber: 4, sugars: 3, satFat: 1.1 },
  { keys: ["dolma", "stuffed grape leaves"], kcal: 145, carbs: 18, protein: 2.5, fat: 7, fiber: 2.5, sugars: 1.5, satFat: 0.9 },
  { keys: ["biryani rice middle eastern", "mandi", "kabsa"], kcal: 195, carbs: 26, protein: 9, fat: 6.5, fiber: 1, sugars: 1.5, satFat: 1.8 },

  // ---- Additional American / breakfast / desserts ----
  { keys: ["clam chowder"], kcal: 90, carbs: 8, protein: 5, fat: 4.5, fiber: 0.5, sugars: 1.5, satFat: 2 },
  { keys: ["chili con carne", "chili"], kcal: 140, carbs: 10, protein: 11, fat: 6.5, fiber: 3.5, sugars: 3, satFat: 2.5 },
  { keys: ["bbq ribs", "barbecue ribs", "ribs"], kcal: 295, carbs: 6, protein: 21, fat: 21, fiber: 0.3, sugars: 4, satFat: 7.5 },
  { keys: ["coleslaw"], kcal: 150, carbs: 10, protein: 1.2, fat: 12, fiber: 2, sugars: 7, satFat: 1.8 },
  { keys: ["pumpkin pie"], kcal: 240, carbs: 30, protein: 4.5, fat: 12, fiber: 1.8, sugars: 18, satFat: 4.5 },
  { keys: ["apple pie"], kcal: 235, carbs: 34, protein: 2, fat: 10, fiber: 1.5, sugars: 18, satFat: 3.5 },
  { keys: ["cheesecake"], kcal: 320, carbs: 26, protein: 5.5, fat: 22, fiber: 0.5, sugars: 21, satFat: 12.5 },
  { keys: ["brownie"], kcal: 405, carbs: 52, protein: 5, fat: 20, fiber: 2, sugars: 38, satFat: 6.5 },
  { keys: ["milkshake"], kcal: 145, carbs: 22, protein: 3.5, fat: 4.5, fiber: 0.2, sugars: 20, satFat: 2.8 },

  // ---- Generic proteins / carbs / veg building blocks ----
  { keys: ["white bread"], kcal: 265, carbs: 49, protein: 9, fat: 3.2, fiber: 2.7, sugars: 5, satFat: 0.7 },
  { keys: ["brown rice", "boiled rice", "steamed rice", "plain rice", "white rice"], kcal: 130, carbs: 28, protein: 2.7, fat: 0.3, fiber: 0.5, sugars: 0.1, satFat: 0.1 },
  { keys: ["plain pasta noodles", "boiled noodles"], kcal: 140, carbs: 27, protein: 5, fat: 1, fiber: 1.5, sugars: 0.5, satFat: 0.2 },
  { keys: ["black beans", "kidney beans", "beans"], kcal: 130, carbs: 22, protein: 8.5, fat: 0.5, fiber: 8, sugars: 0.5, satFat: 0.1 },
  { keys: ["broccoli"], kcal: 35, carbs: 7, protein: 2.8, fat: 0.4, fiber: 2.6, sugars: 1.7, satFat: 0.1 },
  { keys: ["mixed greens", "lettuce"], kcal: 17, carbs: 3, protein: 1.4, fat: 0.2, fiber: 1.5, sugars: 1, satFat: 0 },
  { keys: ["cheddar cheese", "shredded cheese", "cheese"], kcal: 400, carbs: 1.5, protein: 25, fat: 33, fiber: 0, sugars: 0.5, satFat: 21 },
  { keys: ["butter"], kcal: 715, carbs: 0.1, protein: 0.9, fat: 81, fiber: 0, sugars: 0.1, satFat: 51 },
  { keys: ["olive oil", "vegetable oil", "cooking oil"], kcal: 884, carbs: 0, protein: 0, fat: 100, fiber: 0, sugars: 0, satFat: 14 },
  { keys: ["tomato sauce", "marinara"], kcal: 40, carbs: 8, protein: 1.5, fat: 0.5, fiber: 1.5, sugars: 5, satFat: 0.1 },
  { keys: ["ranch dressing", "salad dressing", "mayonnaise"], kcal: 460, carbs: 3, protein: 1, fat: 49, fiber: 0, sugars: 2, satFat: 7.5 },
];

function normalize(str) {
  return (str || "").toLowerCase().replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
}

/**
 * Same matching strategy as lookupIndianFood: keyword-based substring
 * match, preferring the longest (most specific) key. Kept as a
 * separate function/module so cuisine-specific DBs can be prioritized
 * independently in analyse.js (Indian DB checked first, this one second).
 */
function lookupWorldFood(name) {
  const q = normalize(name);
  if (!q) return null;

  let best = null;
  let bestLen = 0;

  for (const entry of WORLD_FOOD_DB) {
    for (const key of entry.keys) {
      if (q.includes(key) && key.length > bestLen) {
        best = entry;
        bestLen = key.length;
      }
    }
  }

  if (!best) return null;
  const { kcal, carbs, protein, fat, fiber, sugars, satFat } = best;
  return { kcal, carbs, protein, fat, fiber, sugars, satFat };
}

module.exports = { lookupWorldFood, WORLD_FOOD_DB };
